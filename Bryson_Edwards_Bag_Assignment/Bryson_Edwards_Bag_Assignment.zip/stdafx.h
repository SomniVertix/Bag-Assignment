// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <iostream>
#include <tchar.h>
#include <stdlib.h>

#include "ABag.h"
#include "kvpair.h"
#include "BDictionary.h"

#include "dictionaryADT.h"
#include "bagADT.h"
#include "book.h"



// TODO: reference additional headers your program requires here
